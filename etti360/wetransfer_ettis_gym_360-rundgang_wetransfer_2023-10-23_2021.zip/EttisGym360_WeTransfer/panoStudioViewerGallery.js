PanoramaStudioViewerParams = {
"panoramaStudioViewer":
{
    "gallery": [
        {
            "href": "ettis6.js",
            "text": "Zufahrt",
            "thumbnail": "ettis6_tiles/ettis6_thumb.jpg"
        },
        {
            "href": "ettis1.js",
            "text": "Pos1",
            "thumbnail": "ettis1_tiles/ettis1_thumb.jpg"
        },
        {
            "href": "ettis2.js",
            "text": "Pos2",
            "thumbnail": "ettis2_tiles/ettis2_thumb.jpg"
        },
        {
            "href": "ettis3.js",
            "text": "Pos3",
            "thumbnail": "ettis3_tiles/ettis3_thumb.jpg"
        },
        {
            "href": "ettis4.js",
            "text": "Pos4",
            "thumbnail": "ettis4_tiles/ettis4_thumb.jpg"
        },
        {
            "href": "ettis5.js",
            "text": "Pos5",
            "thumbnail": "ettis5_tiles/ettis5_thumb.jpg"
        }
    ]
}

}